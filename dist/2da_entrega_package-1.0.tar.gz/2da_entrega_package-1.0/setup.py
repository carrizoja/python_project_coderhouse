from setuptools import setup
setup(
    name='2da_entrega_package',
    version='1.0',
    description='Classes and packages for the Python course',
    author= "José Carrizo",
    author_email= "carrizoja@gmail.com",
    packages=["class_package","primera_entrega_package"]
)